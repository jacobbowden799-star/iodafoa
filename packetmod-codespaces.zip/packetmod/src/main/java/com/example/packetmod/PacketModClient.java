package com.example.packetmod;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;

/**
 * /packets <amount>             - send all packets in one tick
 * /packets <amount> <perTick>   - send <perTick> packets each tick until <amount> are sent
 * /packets stop                 - cancel a running job
 */
public class PacketModClient implements ClientModInitializer {

    private static int remaining = 0;
    private static int perTick = 0;
    private static int totalSent = 0;

    @Override
    public void onInitializeClient() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
            dispatcher.register(ClientCommandManager.literal("packets")
                .then(ClientCommandManager.literal("stop")
                    .executes(ctx -> {
                        int cancelled = remaining;
                        remaining = 0;
                        msg("Stopped. Sent " + totalSent + ", cancelled " + cancelled + ".");
                        return 1;
                    }))
                .then(ClientCommandManager.argument("amount", IntegerArgumentType.integer(1, 100000))
                    .executes(ctx -> {
                        int amount = IntegerArgumentType.getInteger(ctx, "amount");
                        return start(amount, amount);
                    })
                    .then(ClientCommandManager.argument("perTick", IntegerArgumentType.integer(1, 1000))
                        .executes(ctx -> start(
                            IntegerArgumentType.getInteger(ctx, "amount"),
                            IntegerArgumentType.getInteger(ctx, "perTick")))))
            )
        );

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (remaining <= 0) return;
            LocalPlayer player = client.player;
            if (player == null || player.connection == null) {
                remaining = 0;
                return;
            }

            int batch = Math.min(perTick, remaining);
            for (int i = 0; i < batch; i++) {
                player.connection.send(new ServerboundMovePlayerPacket.PosRot(
                    player.getX(), player.getY(), player.getZ(),
                    player.getYRot(), player.getXRot(),
                    player.onGround(), player.horizontalCollision
                ));
            }
            remaining -= batch;
            totalSent += batch;

            if (remaining <= 0) {
                msg("Done. Sent " + totalSent + " movement packets.");
            }
        });
    }

    private static int start(int amount, int batchSize) {
        LocalPlayer player = Minecraft.getInstance().player;
        if (player == null || player.connection == null) return 0;

        remaining = amount;
        perTick = batchSize;
        totalSent = 0;

        int ticks = (amount + batchSize - 1) / batchSize;
        msg("Sending " + amount + " packets, " + batchSize + " per tick (" + ticks + " ticks).");
        return amount;
    }

    private static void msg(String text) {
        LocalPlayer player = Minecraft.getInstance().player;
        if (player != null) player.displayClientMessage(Component.literal(text), false);
    }
}
