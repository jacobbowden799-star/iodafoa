#!/usr/bin/env bash
set -euo pipefail
if ! command -v java >/dev/null 2>&1; then
  echo 'Java is missing.' >&2
  exit 1
fi
java -version
gradle --version
gradle build
printf '\nBuild complete. JAR files:\n'
find build/libs -maxdepth 1 -type f -name '*.jar' ! -name '*-sources.jar' -print
