# Packet Mod (Fabric, Minecraft 26.3, client-side)

Commands:
  /packets <amount>            send all packets in one tick
  /packets <amount> <perTick>  send <perTick> packets each tick until <amount> are sent
  /packets stop                cancel a running job
Example: /packets 500 20  ->  500 packets, 20 per tick (25 ticks, about 1.25 s).

## Build
Requires JDK 25 and Gradle 9.6+ (or open the folder in IntelliJ IDEA, which handles Gradle).

    gradle wrapper --gradle-version 9.6.0     # once, creates ./gradlew
    ./gradlew build                           # Windows: gradlew.bat build

The jar is in build/libs/packetmod-1.0.0.jar (not the -sources jar).
Put it in your mods folder with Fabric API 0.160.6+26.3 or newer.

Use only in singleplayer or on servers you run; bursts of movement packets get flagged by anti-cheat.
